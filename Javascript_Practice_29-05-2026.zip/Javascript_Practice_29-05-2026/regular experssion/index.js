// Regular Expressions (RegEx) in JavaScript

// Regular Expressions (RegEx) are patterns used to:

// Search text
// Match patterns
// Validate input
// Replace text
// Extract data

// JavaScript provides built-in support using the RegExp object.

let text = "hello world";

console.log(/world/.test(text));

let tex = "HELLO";

console.log(/hello/i.test(tex));

//replace

let texts = "I like cats";

let result = texts.replace(/cats/, "dogs");

console.log(result);

let textt = "7";

console.log(/[0-9]/.test(textt));

let mobile = "9876543210";

let pattern = /^[0-9]{10}$/;

console.log(pattern.test(mobile));

let password = "Hello123";

let pattern = /^(?=.*[A-Z])(?=.*\d).{8,}$/;

console.log(pattern.test(password));