// Operators 
// Arithmetic Operators

// Used for mathematical calculations.

// Operator	Meaning
// +	Addition
// -	Subtraction
// *	Multiplication
// /	Division
// %	Modulus
// **	Power

var a = 10;
var b = 20;

console.log(a + b);

var a = 10;
var b = 20;
var c = a+b;

console.log(c);


var a = 10;
var b = 20;
var c = a-b;

console.log(c);


var a = 10;
var b = 20;
var c = a*b;

console.log(c);


var a = 10;
var b = 20;
var c = a/b;

console.log(c);

var a = 10;
var b = 20;
var c = a%b;

console.log(c);


var a = 10;
var b = 20;
var c = a**b;
console.log(c);

// Comparision operator


var a = 10;
var b = 20;
var c = a==b;

console.log(c);


var a = 10;
var b = 20;
var c = a===b;

console.log(c);

var a = 10;
var b = 20;
var c = a<b;

console.log(c);

var a = 10;
var b = 20;
var c = a>b;

console.log(c);

console.log(10 === "10");


let age = 20;

console.log(age > 18);

console.log(5 != 10);

// Logical Operators

// Used to combine conditions.

// Operator	Meaning
// &&	AND
// `	
// !	NOT

let age = 22;
let hasLicense = true;

console.log(age >= 18 && hasLicense);

let citizen = true;
let age = 19;

console.log(citizen && age >= 18);

let username = "admin";
let password = "1234";

console.log(username === "admin" && password === "1234");


// in && operator both cases is to pass the only i will print true otherwise false
let isHoliday = false;
let isSunday = true;

console.log(isHoliday || isSunday);
// in OR operator any one shoulde be true






