// JavaScript map() Method

// The map() method is used to:

// Iterate through an array
// Transform each element
// Return a new array

// It does not modify the original array.

// 1. Syntax

let student = new Map();

student.set("name", "Rahul");
student.set("age", 21);
student.set("course", "JavaScript");

console.log(student); 


let employee = new Map();

employee.set("id", 101);
employee.set("name", "Kiran");

console.log(employee.get("name"));
console.log(employee.get("id"));

let products = new Map();

products.set("laptop", 55000);
products.set("mobile", 20000);

console.log(products.has("laptop"));
console.log(products.has("tv"));